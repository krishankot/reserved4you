</html>
<!DOCTYPE html>
<html>
   <head>
      <title>Become Partner</title>
   </head>
   <body style="margin: 0;">      
      <div class="">
         <div class="aHl">
         </div>
         <div id=":mr" tabindex="-1"></div>
         <div id=":mg" class="ii gt">
            <div id=":mf" class="a3s aXjCH msg-2062990872043412041">
               <u></u>
               <div style="text-align:center;min-width:640px;width:100%;height:100%;font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;margin:0;padding:0" bgcolor="#ffffff">
                  <table border="0" cellpadding="0" cellspacing="0" id="m_-2062990872043412041body" style="text-align:center;min-width:640px;width:100%;margin:0;padding:0" bgcolor="#ffffff">
                     <tbody>
                        <tr>
                           <td style="font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;height:4px;font-size:4px;line-height:4px" bgcolor="#6b4fbb"></td>
                        </tr>
                        
                        <tr>
                           <td style="font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif">
                              <table border="0" cellpadding="0" cellspacing="0" class="m_-2062990872043412041wrapper" style="width:640px;border-collapse:separate;border-spacing:0;margin:0 auto">
                                 <tbody>
                                    <tr>
                                       <td class="m_-2062990872043412041wrapper-cell" style="font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;border-radius:3px;overflow:hidden;border:1px solid #ededed" align="left" bgcolor="#fafafa">
                                          <table border="0" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:separate;border-spacing:0">
                                             <tbody>
                                                <tr>
                                                   <td style="font-family:&quot;Helvetica Neue&quot;,Helvetica,Arial,sans-serif;font-size:13px;justify-content: center;align-items: center; line-height:1.6; text-align: center; color:#5c5c5c; padding:25px 0" bgcolor="#ffffff">
                                                      <img alt="GitLab" src="{{ $message->embed(public_path() . '/logo.png') }}" width="500" height="80" class="CToWUd">
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td style="font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;color:#333333;font-size:15px;font-weight:400;line-height:1.4;padding:25px;" align="center">
												   <tr>
													<td align="center" style="padding:0px 5px 0 5px;">
														<table cellspacing="0" cellpadding="10">	
															<tr>
																<td>
																	<h1 style="color: #707070; margin: 0; font-family: Arial Black,Arial,Helvetica; text-align: center; font-size: 25px;">Hello Admin,</h1>
																</td>
															</tr>

															<tr>
																<td style="font-family: Arial,Helvetica;">
                                                   <h2>Hello</h2>
                                                   You received an appointment to become a business partner : {{ $first_name }}<br />
                                                   Here are the details:<br />
                                                   <b>Store Name:</b> {{ $store_name }}<br />
												   <b>First Name:</b> {{ $first_name }}<br />
												   <b>Last Name:</b> {{ $last_name }}<br />
                                                   <b>Email:</b> {{ $email }}<br />
												   <b>Phone:</b> {{ $phone }}<br />
												   <b>Postal Code:</b> {{ $postal_code }}<br />
												   <b>How to meet:</b> {{ $howtomeet }}<br />
                                                   <b>Appointment Date:</b> {{ $app_date }}<br />
												    <b>Appointment Time:</b> {{ $app_time }}<br />
                                                   Thank You
																</td>
															</tr>

														</table>
													</td>
												</tr>
                                                   </td>
                                                </tr>
                                                <tr>
                                                     <td style="text-align: center; font-family: Arial,Helvetica; color: #000000; background: #ffffff; border-top: 1px solid #fff;">
                                                         <p style="margin: 0; font-size: 15px; font-family: Arial,Helvetica ; margin: 10px">Copyright &copy; Reserved4you app rights reserved.</p>
                                                     </td>
                                                 </tr>
                                             </tbody>
                                          </table>
                                       </td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                        </tr>
                     </tbody>
                  </table>
                  <div class="yj6qo">
                  </div>
                  <div class="adL">
                  </div>
               </div>
               <div class="adL">
               </div>
            </div>
         </div>
         <div id=":mw" class="ii gt" style="display:none">
            <div id=":mv" class="a3s aXjCH undefined"></div>
         </div>
         <div class="hi"></div>
      </div>
   </body>
</html>
