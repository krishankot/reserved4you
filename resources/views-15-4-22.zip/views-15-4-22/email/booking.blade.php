<html>
<head>
    <title>Reserved 4 you</title>
</head>
<body>

<div style="width: 616px; position: relative;padding: 15px; padding-bottom: 15px;  margin: 0 auto; font-family: Gadugi; background-color: whitesmoke;">
    <div style=" text-align: center; padding: 15px; border-bottom: 1px solid lightgray; ">
        <a href="javascript:void(0)"><img src="https://decodes-studio.com/reserved4you/storage/app/public/Frontassets/images/logo.png" style="max-width: 250px;" ></a>
    </div>

    <div style="text-align: center; padding-top: 20px;">
        <img src="{{$image}}" style="text-align: center;  border-radius: 10px; max-width: 250px;">
        <div style="line-height: 15px;">
            <h1 style="padding-bottom: 8px;">{{$service}}</h1>
            <p style="font-size: 18px;">{{$store}}</p>
            <p style="font-size: 18px">{{$expert}}</p>
        </div>
    </div>
    <div style=" text-align: center; padding-top: 10px; line-height: 0px;">
        <label style="font-size: 18px; padding-right: 30px;"><b>Date :- </b>{{$date}}</label> <label style="font-size: 18px;"><b>Time :- </b>{{$time}}</label>
    </div>
    <h1 style="font-size: 35px; margin-bottom: 0px;line-height: 50px; text-align: center; color:black">{{$price}}€</h1>


    <div style="text-align: center;">
        <p style="font-size: 16px;"><b>Payment Type :-</b> {{$payment_type}}</p>
        <p style="font-size: 16px;"><b>Order ID :-</b> #{{$order_id}}</p>
        <p style="font-size: 16px;"><b>Payment ID :-</b> {{$payment_id}}</p>


    </div>

    <h1 style="font-size: 30px;  text-align: center; color:rgb(17, 146, 17)">Payment {{$status}}</h1>
    <div style="text-align: center; margin-bottom: 40px; ;">
        <a href="#"><button style="padding:8px 16px 8px 16px; outline: none;color: white;  border: none;   background-color:black; font-size: 18px; border-radius: 10px; width: auto; max-width: 250px;  ">Continue Shopping</button></a>
    </div>



    <div  style="border-top: 1px solid lightgray; padding: 20px 20px 0px 20px; margin: 0 auto; text-align: center;">
        <a href="javascrip:void(0)" style="margin-left: 10px; "><img src="https://decodes-studio.com/reserved4you/storage/app/public/Frontassets/images/facebook.png" style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="https://decodes-studio.com/reserved4you/storage/app/public/Frontassets/images/Instagram.png"  style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="https://decodes-studio.com/reserved4you/storage/app/public/Frontassets/images/Twitter.png"  style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="https://decodes-studio.com/reserved4you/storage/app/public/Frontassets/images/Pinterest.png"  style="width: 35px;"></a>
    </div>
    <p style="text-align: center; font-size: 15px; opacity: 50%; ">This message was sent from Reserved 4 you, </p>
</div>

</body>
</html>
