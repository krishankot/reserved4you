<html>
<head>
    <title>Reserved 4 you</title>
</head>
<body>

<div style="width: 616px; position: relative; padding: 15px; font-family: Gadugi; margin: 0 auto; background-color: whitesmoke;">
    <div style=" text-align: center; padding: 20px; border-bottom: 1px solid lightgray; ">
        <a href="javascript:void(0)"><img src="{{ asset('public/logo.png') }}" style="max-width: 250px;" ></a>
		<h6>SMART MANAGEMENT. BETTER SERVICE.</h6>
    </div>
    <div >
        <h1 style="font-size: 20px; padding: 0px 0px 0px 0px; text-align: center; ">Hallo {{$name}} </h1>

        <p style="font-size: 20px;text-align: center; padding: 0px 0px 10px 0px; ">vielen Dank für deine Registrierung bei reserved4you. 
Bitte verifiziere deine E-Mail-Adresse, um zu bestätigen, dass dieses Konto dir gehört und so zusätzliche Sicherheit zu gewährleisten. An diese Adresse werden Benachrichtigungen zu deinen Kontoaktivitäten gesendet.</p>
		 <p style="font-size: 20px;text-align: center; padding: 0px 0px 10px 0px; ">Verwenden Sie das folgende OTP zur Überprüfung: </p>
	   <div style="text-align: center; margin-bottom: 30px;">
            <h3 style="font-weight:800;fort-size:24px;">{{$otp}}</h3>
        </div>
    </div>
	<div  style="border-top: 1px solid lightgray; padding: 15px; margin: 0 auto; ">
	<p>R.F.U. reserved4you GmbH<br />
Geschäftsführender Gesellschafter: Hadi Ballout<br />
Geschäftsführerin: Pia Lulei</p>

<p>Wilmersdorfer Straße 122/123<br />
10627 Berlin</p>

<p>Webseite: www.reserved4you.de</p>
                

<p>E-Mail:<br />      info@reserved4you.de<br />
                 pia.lulei@reserved4you.de</p>


<p>Telefon:<br />    0162 647 293 8<br /> 
                 030 978 649 53</p>

<p>Registergericht: Amtsgericht Charlottenburg, HRB 208249 B</p>
	{{-- <div  style="border-top: 1px solid lightgray; padding: 20px 20px 0px 20px; margin: 0 auto; text-align: center;">
        <a href="javascrip:void(0)" style="margin-left: 10px; "><img src="{{ asset('storage/app/public/Frontassets/images/facebook.png') }}" style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="{{ asset('storage/app/public/Frontassets/images/Instagram.png') }}"  style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="{{ asset('storage/app/public/Frontassets/images/Twitter.png') }}"  style="width: 35px;"></a>
        <a href="javascrip:void(0)" style="margin-left: 10px;"><img src="{{ asset('storage/app/public/Frontassets/images/Pinterest.png') }}"  style="width: 35px;"></a>
    </div> --}}
    <p style="text-align: center; font-size: 15px; opacity: 50%;">Copyright &copy;Reserved4you rights reserved. </p>
</div>

</body>
</html>
